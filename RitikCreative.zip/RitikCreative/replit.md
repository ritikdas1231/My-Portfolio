# Overview

This is a full-stack video editor portfolio website built as a Single Page Application (SPA) for Ritik, a video editor and motion designer. The project showcases his work, skills, and provides a contact form for potential clients. The application uses a modern tech stack with React frontend, Express backend, PostgreSQL database, and is styled with a dark theme using Tailwind CSS and shadcn/ui components.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React SPA**: Uses React with TypeScript for the client-side application
- **Routing**: Wouter for lightweight client-side routing with a simple home page and 404 fallback
- **State Management**: React Query (TanStack Query) for server state management and API calls
- **Styling**: Tailwind CSS with a custom dark theme configuration and shadcn/ui component library
- **UI Components**: Comprehensive set of Radix UI primitives wrapped in custom components (buttons, forms, cards, etc.)

## Backend Architecture
- **Express Server**: Node.js with Express framework handling API routes and static file serving
- **Development Setup**: Vite integration for hot module replacement in development
- **API Structure**: RESTful endpoints with `/api/contact` for form submissions
- **Email Service**: Nodemailer integration for sending contact form emails via Gmail
- **Error Handling**: Centralized error middleware with proper HTTP status codes

## Database & ORM
- **PostgreSQL**: Primary database using Neon Database serverless PostgreSQL
- **Drizzle ORM**: Type-safe database queries and schema management
- **Schema**: Contact messages table with id, name, email, message, and timestamp fields
- **Migrations**: Drizzle Kit for database schema migrations

## Development & Build
- **TypeScript**: Full TypeScript support across client, server, and shared modules
- **Build System**: Vite for frontend bundling and esbuild for server compilation
- **Module Structure**: Monorepo structure with `client/`, `server/`, and `shared/` directories
- **Path Aliases**: Configured aliases for clean imports (`@/` for client, `@shared/` for shared)

## External Dependencies

- **Neon Database**: Serverless PostgreSQL database hosting
- **Gmail SMTP**: Email service for contact form submissions using nodemailer
- **Google Fonts**: Inter font family loaded via CDN
- **Unsplash**: Placeholder images for portfolio showcase
- **Radix UI**: Headless UI primitives for accessible component foundation
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Replit Integration**: Vite plugins for Replit development environment support