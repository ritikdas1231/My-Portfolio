import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { insertContactMessageSchema } from "@shared/schema";
import nodemailer from "nodemailer";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactMessageSchema.parse(req.body);
      
      // Create email transporter
      const transporter = nodemailer.createTransporter({
        service: 'gmail',
        auth: {
          user: process.env.EMAIL_USER || 'infos1231@gmail.com',
          pass: process.env.EMAIL_PASS || 'your-app-password'
        }
      });

      // Email to Ritik
      const mailOptions = {
        from: process.env.EMAIL_USER || 'infos1231@gmail.com',
        to: 'infos1231@gmail.com',
        subject: `New Contact Form Submission from ${validatedData.name}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #0F172A;">New Contact Form Submission</h2>
            <div style="background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <p><strong>Name:</strong> ${validatedData.name}</p>
              <p><strong>Email:</strong> ${validatedData.email}</p>
              <p><strong>Message:</strong></p>
              <p style="background-color: white; padding: 15px; border-radius: 4px; border-left: 4px solid #3B82F6;">
                ${validatedData.message.replace(/\n/g, '<br>')}
              </p>
            </div>
            <p style="color: #64748B; font-size: 14px;">
              This message was sent from your portfolio website contact form.
            </p>
          </div>
        `
      };

      await transporter.sendMail(mailOptions);

      res.json({ 
        success: true, 
        message: "Message sent successfully! I'll get back to you soon." 
      });

    } catch (error) {
      console.error('Contact form error:', error);
      res.status(500).json({ 
        success: false, 
        message: "Something went wrong. Please try again or contact me directly." 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
