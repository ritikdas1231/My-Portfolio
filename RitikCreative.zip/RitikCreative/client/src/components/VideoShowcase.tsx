import { Play, Video } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const VideoShowcase = () => {
  return (
    <section id="showcase" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4" data-testid="showcase-title">
            Video Showcase
          </h2>
          <p className="text-xl text-muted-foreground" data-testid="showcase-description">
            Featured work and creative highlights
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {/* Main Video Showcase */}
          <Card className="md:col-span-2 glassmorphism bg-card/50 backdrop-blur-sm border-border">
            <CardContent className="p-6">
              <div className="aspect-video bg-muted rounded-xl flex items-center justify-center mb-4" data-testid="main-video-placeholder">
                <div className="text-center">
                  <Play className="mx-auto mb-4 h-16 w-16 text-primary" />
                  <p className="text-xl font-semibold">Featured Video Reel</p>
                  <p className="text-muted-foreground">YouTube/Vimeo embed placeholder</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    Replace this with actual video embed code
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Video Grid */}
          <Card className="glassmorphism bg-card/50 backdrop-blur-sm border-border">
            <CardContent className="p-6">
              <div className="aspect-video bg-muted rounded-xl flex items-center justify-center mb-4" data-testid="video-placeholder-1">
                <div className="text-center">
                  <Video className="mx-auto mb-2 h-8 w-8 text-primary" />
                  <p className="text-sm font-semibold">Brand Commercial</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="glassmorphism bg-card/50 backdrop-blur-sm border-border">
            <CardContent className="p-6">
              <div className="aspect-video bg-muted rounded-xl flex items-center justify-center mb-4" data-testid="video-placeholder-2">
                <div className="text-center">
                  <Video className="mx-auto mb-2 h-8 w-8 text-primary" />
                  <p className="text-sm font-semibold">Motion Graphics</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default VideoShowcase;
