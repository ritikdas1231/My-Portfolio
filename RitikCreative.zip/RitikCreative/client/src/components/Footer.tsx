import { MessageCircle, Mail, Instagram, Phone } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-card border-t border-border py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8 items-center">
          <div>
            <div className="text-2xl font-bold bg-gradient-to-r from-primary to-purple-500 bg-clip-text text-transparent mb-2">
              Ritik
            </div>
            <p className="text-muted-foreground" data-testid="footer-tagline">
              Video Editor & Motion Designer
            </p>
          </div>
          
          <div className="text-center">
            <div className="flex justify-center space-x-6">
              <a 
                href="https://wa.me/919835609158" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-green-400 transition-colors"
                data-testid="footer-whatsapp"
              >
                <MessageCircle className="h-6 w-6" />
              </a>
              <a 
                href="mailto:infos1231@gmail.com" 
                className="text-muted-foreground hover:text-red-400 transition-colors"
                data-testid="footer-email"
              >
                <Mail className="h-6 w-6" />
              </a>
              <a 
                href="https://instagram.com/iamritikdas" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-pink-400 transition-colors"
                data-testid="footer-instagram"
              >
                <Instagram className="h-6 w-6" />
              </a>
              <a 
                href="tel:+919835609158" 
                className="text-muted-foreground hover:text-primary transition-colors"
                data-testid="footer-phone"
              >
                <Phone className="h-6 w-6" />
              </a>
            </div>
          </div>
          
          <div className="text-center md:text-right">
            <p className="text-muted-foreground" data-testid="footer-copyright">
              © 2024 Ritik. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
