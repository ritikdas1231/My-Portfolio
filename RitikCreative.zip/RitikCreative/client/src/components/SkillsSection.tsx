import { useEffect, useRef } from "react";
import { 
  SiAdobeaftereffects, 
  SiAdobepremierepro, 
  SiDavinciresolve, 
  SiAdobephotoshop, 
  SiAdobeillustrator, 
  SiCanva, 
  SiBlender 
} from "react-icons/si";
import { Scissors } from "lucide-react";

interface Skill {
  name: string;
  percentage: number;
  Icon: React.ComponentType<any>;
  color: string;
  bgColor: string;
}

const skills: Skill[] = [
  { 
    name: "After Effects", 
    percentage: 95, 
    Icon: SiAdobeaftereffects, 
    color: "text-purple-400", 
    bgColor: "bg-purple-500/20"
  },
  { 
    name: "Premiere Pro", 
    percentage: 92, 
    Icon: SiAdobepremierepro, 
    color: "text-purple-400", 
    bgColor: "bg-purple-500/20"
  },
  { 
    name: "DaVinci Resolve", 
    percentage: 90, 
    Icon: SiDavinciresolve, 
    color: "text-red-400", 
    bgColor: "bg-red-500/20"
  },
  { 
    name: "Photoshop", 
    percentage: 93, 
    Icon: SiAdobephotoshop, 
    color: "text-blue-400", 
    bgColor: "bg-blue-500/20"
  },
  { 
    name: "Illustrator", 
    percentage: 90, 
    Icon: SiAdobeillustrator, 
    color: "text-orange-400", 
    bgColor: "bg-orange-500/20"
  },
  { 
    name: "Canva", 
    percentage: 88, 
    Icon: SiCanva, 
    color: "text-cyan-400", 
    bgColor: "bg-cyan-500/20"
  },
  { 
    name: "CapCut", 
    percentage: 85, 
    Icon: Scissors, 
    color: "text-pink-400", 
    bgColor: "bg-pink-500/20"
  },
  { 
    name: "Blender", 
    percentage: 82, 
    Icon: SiBlender, 
    color: "text-orange-400", 
    bgColor: "bg-orange-500/20"
  },
];

const SkillCard = ({ skill, index }: { skill: Skill; index: number }) => {
  const progressRef = useRef<HTMLDivElement>(null);
  const circleRef = useRef<SVGSVGElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  
  // Alternate between different progress bar styles
  const isCircular = index % 2 === 0;

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setTimeout(() => {
              if (isCircular && circleRef.current) {
                // Circular progress animation
                const circle = circleRef.current.querySelector('circle:last-child') as SVGCircleElement;
                if (circle) {
                  const circumference = 2 * Math.PI * 45;
                  const offset = circumference - (skill.percentage / 100) * circumference;
                  circle.style.strokeDashoffset = offset.toString();
                  circle.style.transition = 'stroke-dashoffset 2s ease-out';
                }
              } else if (!isCircular && progressRef.current) {
                // Linear progress animation
                progressRef.current.style.width = `${skill.percentage}%`;
                progressRef.current.style.transition = 'width 2s ease-out';
              }
            }, index * 200 + 300); // Staggered animation
          }
        });
      },
      { threshold: 0.3 }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => observer.disconnect();
  }, [skill.percentage, isCircular, index]);

  return (
    <div 
      ref={cardRef}
      className="glassmorphism bg-card/50 backdrop-blur-sm rounded-2xl p-6 hover:bg-card/70 transition-all duration-300 transform hover:scale-105 group"
      data-testid={`skill-card-${skill.name.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <div className="flex flex-col items-center">
        {/* Software Logo */}
        <div className={`w-16 h-16 ${skill.bgColor} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
          <skill.Icon className={`w-8 h-8 ${skill.color}`} />
        </div>
        
        <h3 className="text-lg font-semibold mb-4 text-center" data-testid={`skill-name-${skill.name.toLowerCase().replace(/\s+/g, '-')}`}>
          {skill.name}
        </h3>
        
        {/* Progress Display */}
        {isCircular ? (
          // Circular Progress Bar
          <div className="relative w-24 h-24 mb-2">
            <svg ref={circleRef} className="w-24 h-24 transform -rotate-90" viewBox="0 0 100 100">
              <circle 
                cx="50" 
                cy="50" 
                r="45" 
                stroke="hsl(var(--muted))" 
                strokeWidth="6" 
                fill="none" 
              />
              <circle 
                cx="50" 
                cy="50" 
                r="45" 
                stroke="url(#gradient1)" 
                strokeWidth="6" 
                fill="none" 
                strokeDasharray={2 * Math.PI * 45}
                strokeDashoffset={2 * Math.PI * 45}
                strokeLinecap="round"
                className="drop-shadow-sm"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-lg font-bold" data-testid={`skill-percentage-${skill.name.toLowerCase().replace(/\s+/g, '-')}`}>
                {skill.percentage}%
              </span>
            </div>
          </div>
        ) : (
          // Linear Progress Bar
          <div className="w-full mb-2">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-muted-foreground">Proficiency</span>
              <span className="text-lg font-bold" data-testid={`skill-percentage-${skill.name.toLowerCase().replace(/\s+/g, '-')}`}>
                {skill.percentage}%
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
              <div 
                ref={progressRef}
                className="h-full bg-gradient-to-r from-primary to-purple-500 rounded-full transition-all duration-300 shadow-lg"
                style={{ width: '0%' }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const SkillsSection = () => {
  return (
    <section id="skills" className="py-20 bg-card/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4" data-testid="skills-title">My Skills</h2>
          <p className="text-xl text-muted-foreground" data-testid="skills-description">
            Professional software expertise for video editing and motion graphics
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skills.map((skill, index) => (
            <SkillCard key={skill.name} skill={skill} index={index} />
          ))}
        </div>
      </div>

      {/* SVG Gradients */}
      <svg className="absolute w-0 h-0" aria-hidden="true">
        <defs>
          <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="hsl(var(--primary))" />
            <stop offset="100%" stopColor="hsl(271, 91%, 65%)" />
          </linearGradient>
        </defs>
      </svg>
    </section>
  );
};

export default SkillsSection;
