import { Play } from "lucide-react";
import { Button } from "@/components/ui/button";

const HeroSection = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-purple-500/20"></div>
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-float" style={{animationDelay: '-3s'}}></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <div className="mb-6 animate-fadeInUp">
              <h1 className="text-5xl md:text-7xl font-bold mb-4" data-testid="hero-title">
                Hi, I'm <span className="bg-gradient-to-r from-primary to-purple-500 bg-clip-text text-transparent">Ritik</span>
              </h1>
              <h2 className="text-2xl md:text-3xl text-muted-foreground mb-6" data-testid="hero-subtitle">
                Video Editor & Motion Designer
              </h2>
              <p className="text-lg text-muted-foreground max-w-lg mx-auto lg:mx-0" data-testid="hero-description">
                I create clean, cinematic edits and motion design for brands, creators and businesses.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                onClick={() => scrollToSection('portfolio')}
                className="bg-gradient-to-r from-primary to-purple-500 text-white px-8 py-4 rounded-full font-semibold hover:shadow-lg hover:shadow-primary/25 transition-all duration-300 transform hover:scale-105"
                data-testid="button-view-work"
              >
                <Play className="mr-2 h-4 w-4" />
                View My Work
              </Button>
              <Button 
                variant="outline"
                onClick={() => scrollToSection('contact')}
                className="border-border text-muted-foreground px-8 py-4 rounded-full font-semibold hover:bg-card transition-colors"
                data-testid="button-contact"
              >
                Get In Touch
              </Button>
            </div>
          </div>
          
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              <div className="w-80 h-80 rounded-full bg-gradient-to-br from-primary to-purple-500 p-1">
                <div className="w-full h-full rounded-full bg-card overflow-hidden">
                  <img 
                    src="@assets/photo_2025-02-22_15-31-36_1754792269257.jpg" 
                    alt="Ritik - Video Editor & Motion Designer" 
                    className="w-full h-full object-cover"
                    data-testid="profile-image"
                  />
                </div>
              </div>
              <div className="absolute -bottom-4 -right-4 bg-gradient-to-r from-primary to-purple-500 text-white p-3 rounded-full">
                <Play className="h-6 w-6" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
