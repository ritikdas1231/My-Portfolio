import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Project {
  id: string;
  title: string;
  description: string;
  image: string;
  tags: string[];
  tagColors: string[];
}

const projects: Project[] = [
  {
    id: "1",
    title: "Brand Commercial",
    description: "A dynamic commercial featuring smooth transitions and compelling storytelling for a tech startup.",
    image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    tags: ["After Effects", "Premiere Pro"],
    tagColors: ["bg-primary/20 text-primary", "bg-purple-500/20 text-purple-400"]
  },
  {
    id: "2", 
    title: "Documentary Edit",
    description: "Emotional documentary piece with color grading and sound design that captures authentic human stories.",
    image: "https://images.unsplash.com/photo-1478720568477-b0e6e8b79e5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    tags: ["DaVinci Resolve", "Blender"],
    tagColors: ["bg-red-500/20 text-red-400", "bg-green-500/20 text-green-400"]
  },
  {
    id: "3",
    title: "Motion Graphics",
    description: "Animated logo reveal and brand identity package with modern geometric elements.",
    image: "https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    tags: ["After Effects", "Illustrator"],
    tagColors: ["bg-primary/20 text-primary", "bg-orange-500/20 text-orange-400"]
  },
  {
    id: "4",
    title: "Social Media Content",
    description: "Engaging short-form content for Instagram and TikTok with trending effects and transitions.",
    image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    tags: ["CapCut", "Canva"],
    tagColors: ["bg-pink-500/20 text-pink-400", "bg-cyan-500/20 text-cyan-400"]
  },
  {
    id: "5",
    title: "Music Video",
    description: "High-energy music video with creative visual effects and rhythm-based editing.",
    image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    tags: ["Premiere Pro", "Photoshop"],
    tagColors: ["bg-purple-500/20 text-purple-400", "bg-blue-500/20 text-blue-400"]
  },
  {
    id: "6",
    title: "Corporate Training",
    description: "Professional training videos with clear explanations and engaging visual aids for corporate clients.",
    image: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    tags: ["DaVinci Resolve", "Illustrator"],
    tagColors: ["bg-red-500/20 text-red-400", "bg-orange-500/20 text-orange-400"]
  },
];

const Portfolio = () => {
  return (
    <section id="portfolio" className="py-20 bg-card/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4" data-testid="portfolio-title">
            Portfolio
          </h2>
          <p className="text-xl text-muted-foreground" data-testid="portfolio-description">
            Recent projects and creative work
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Card 
              key={project.id}
              className="glassmorphism bg-card/50 backdrop-blur-sm overflow-hidden hover:bg-card/70 transition-all duration-300 transform hover:scale-105 border-border"
              data-testid={`portfolio-card-${project.id}`}
            >
              <img 
                src={project.image} 
                alt={project.title} 
                className="w-full h-48 object-cover"
                data-testid={`portfolio-image-${project.id}`}
              />
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-2" data-testid={`portfolio-title-${project.id}`}>
                  {project.title}
                </h3>
                <p className="text-muted-foreground mb-4" data-testid={`portfolio-description-${project.id}`}>
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, tagIndex) => (
                    <Badge 
                      key={tag}
                      className={`px-3 py-1 rounded-full text-sm ${project.tagColors[tagIndex]}`}
                      data-testid={`portfolio-tag-${project.id}-${tag.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
